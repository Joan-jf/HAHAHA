(function ($) {
    "use strict";

    // Spinner
    var spinner = function () {
        setTimeout(function () {
            if ($('#spinner').length > 0) {
                $('#spinner').removeClass('show');
            }
        }, 1);
    };
    spinner();
    
    
    // Back to top button
    $(window).scroll(function () {
        if ($(this).scrollTop() > 300) {
            $('.back-to-top').fadeIn('slow');
        } else {
            $('.back-to-top').fadeOut('slow');
        }
    });
    $('.back-to-top').click(function () {
        $('html, body').animate({scrollTop: 0}, 1500, 'easeInOutExpo');
        return false;
    });


    // Sidebar Toggler
    $('.sidebar-toggler').click(function () {
        $('.sidebar, .content').toggleClass("open");
        return false;
    });


    // Progress Bar
    $('.pg-bar').waypoint(function () {
        $('.progress .progress-bar').each(function () {
            $(this).css("width", $(this).attr("aria-valuenow") + '%');
        });
    }, {offset: '80%'});


    // Calender
    $('#calender').datetimepicker({
        inline: true,
        format: 'L'
    });

    // Chart Global Color
    Chart.defaults.color = "#6C7293";
    Chart.defaults.borderColor = "#000000";


    // Spam vs Non-Spam Detection Activity Chart
    var ctx1 = $("#worldwide-sales").get(0).getContext("2d");
    var myChart1 = new Chart(ctx1, {
        type: "bar",
        data: {
            labels: ["Spam", "Non-Spam"],
            datasets: [{
                    label: "Today",
                    data: [15, 30,],
                    backgroundColor: "rgba(235, 22, 22, .7)"
                },
                {
                    label: "1 Month ago",
                    data: [8, 35,],
                    backgroundColor: "rgba(235, 22, 22, .5)"
                },
                {
                    label: "1 Year ago",
                    data: [12, 25,],
                    backgroundColor: "rgba(235, 22, 22, .3)"
                }
            ]
            },
        options: {
            responsive: true
        }
    });


    // Spam vs Non - Spam Chart
    var ctx2 = $("#salse-revenue").get(0).getContext("2d");
    var myChart2 = new Chart(ctx2, {
        type: "line",
        data: {
            labels: ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sept", "Oct", "Nov", "Dec"],
            datasets: [{
                    label: "Spam",
                    data: [15, 30, 55, 45, 70, 65, 85, 27, 17, 69, 38, 12],
                    backgroundColor: "rgba(235, 22, 22, .7)",
                    fill: true
                },
                {
                    label: "Non-Spam",
                    data: [99, 135, 170, 130, 190, 180, 270, 37, 136, 34, 54, 200],
                    backgroundColor: "rgba(235, 22, 22, .5)",
                    fill: true
                }
            ]
            },
        options: {
            responsive: true
        }
    });
    


    // Spam Line Chart
    var ctx3 = $("#line-chart").get(0).getContext("2d");
    var myChart3 = new Chart(ctx3, {
        type: "line",
        data: {
            labels: ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sept", "Oct", "Nov", "Dec"],
            datasets: [{
                label: "Spam",
                fill: false,
                backgroundColor: "rgba(235, 22, 22, .7)",
                data: [7, 2, 8, 32, 9, 27, 10, 11, 14, 87, 15, 12]
            }]
        },
        options: {
            responsive: true
        }
    });


    // Single Bar Chart
    var ctx4 = $("#bar-chart").get(0).getContext("2d");
    var myChart4 = new Chart(ctx4, {
        type: "bar",
        data: {
            labels: ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sept", "Oct", "Nov", "Dec"],
            datasets: [{
                label: "Non-Spam",
                backgroundColor: [
                    "rgba(235, 22, 22, .3)",
                    "rgba(235, 22, 22, .11)",
                    "rgba(235, 22, 22, .5)",
                    "rgba(235, 22, 22, .9)",
                    "rgba(235, 22, 22, .12)",
                    "rgba(235, 22, 22, .2)",
                    "rgba(235, 22, 22, .6)",
                    "rgba(235, 22, 22, .8)",
                    "rgba(235, 22, 22, .4)",
                    "rgba(235, 22, 22, .1)",
                    "rgba(235, 22, 22, .7)",
                    "rgba(235, 22, 22, .10)"
                ],
                data: [55, 49, 44, 24, 15, 32, 89, 27, 3, 29, 43, 12]
            }]
        },
        options: {
            responsive: true
        }
    });


    // Pie Chart
    var ctx5 = $("#pie-chart").get(0).getContext("2d");
    var myChart5 = new Chart(ctx5, {
        type: "pie",
        data: {
            labels: ["Spam", "Non-Spam"],
            datasets: [{
                backgroundColor: [
                    "rgba(235, 22, 22, .7)",
                    "rgba(235, 22, 22, .6)"
                ],
                data: [55, 15]
            }]
        },
        options: {
            responsive: true
        }
    });


    // Doughnut Chart
    var ctx6 = $("#doughnut-chart").get(0).getContext("2d");
    var myChart6 = new Chart(ctx6, {
        type: "doughnut",
        data: {
            labels: ["Spam", "Non-Spam"],
            datasets: [{
                backgroundColor: [
                    "rgba(235, 22, 22, .7)",
                    "rgba(235, 22, 22, .6)"
                ],
                data: [55, 15]
            }]
        },
        options: {
            responsive: true
        }
    });

    
})(jQuery);

